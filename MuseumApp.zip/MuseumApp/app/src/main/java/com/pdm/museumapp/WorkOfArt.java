package com.pdm.museumapp;


import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import static android.view.GestureDetector.*;

public class WorkOfArt extends AppCompatActivity  {

    private static final int SWIPE_TRESHHOLD = 100;
    private static final int SWIPE_VELOCITY_TRESHHOLD = 100;
    private ImageView photo;
    private ImageView Sound;
    private ImageView Video;
    private boolean flagForSound = false;
    private boolean flagForVideo = false;
    private GestureDetector gestureDetector;
    private View.OnTouchListener gestureListener;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_of_art);


        photo = findViewById(R.id.work_photos);
        Sound = findViewById(R.id.mic_button);
        Video = findViewById(R.id.play_video);

        gestureDetector = new GestureDetector(new gestureListener());
        gestureListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(gestureDetector.onTouchEvent(event)){
                    return true;
                }else{
                    return false;
                }

            }
        };
        photo.setOnTouchListener(gestureListener);

    }

    public void gotStart(View view){
        MainActivity.start(this);
    }

    public void playVideo(View view){

        if(!flagForVideo) {
            Video.setImageResource(R.drawable.ic_pause);
            flagForVideo = true;
        }else{
            Video.setImageResource(R.drawable.ic_play_circle_outline_black_24dp);
            flagForVideo = false;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        super.dispatchTouchEvent(ev);
        return gestureDetector.onTouchEvent(ev);
    }

    public void playSound(View view){

        if(!flagForSound) {
            Sound.setImageResource(R.drawable.ic_pause);
            flagForSound = true;
        }else{
            Sound.setImageResource(R.drawable.mic);
            flagForSound = false;
        }
    }

    class gestureListener extends SimpleOnGestureListener {

        @Override
        public boolean onFling(MotionEvent downEvent, MotionEvent moveEvent, float velocityX, float velocityY) {

            boolean result = false;
            float diffy = moveEvent.getY() - downEvent.getY();
            float diffx = moveEvent.getX() - downEvent.getX();

            if (Math.abs(diffx) > Math.abs(diffy)) {
                //Right or Left
                if (Math.abs(diffx) > SWIPE_TRESHHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_TRESHHOLD) {
                    if (diffx > 0) {
                        //Swipe Right
                        onSwipeRight();
                    } else {
                        //Swipe Left
                        onSwipeLeft();
                    }
                    result = true;
                }
            } else {
                //Up or Down
                if (Math.abs(diffy) > SWIPE_TRESHHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_TRESHHOLD) {
                    if (diffy > 0) {
                        //Swipe Down
                        //onSwipeDown();
                    } else {
                        //Swipe Up
                        //onSwipeUp();
                    }
                    result = true;
                }

            }
            return result;
        }
    }

    private void onSwipeLeft() {
       // Toast.makeText(this,"Swipe Left", Toast.LENGTH_LONG).show();
        photo.setImageResource(R.drawable.example2);
    }

    private void onSwipeRight() {
       // Toast.makeText(this,"Swipe Right", Toast.LENGTH_LONG).show();
        photo.setImageResource(R.drawable.example3);
    }

    private void onSwipeUp(){
        Toast.makeText(this,"Swipe UP", Toast.LENGTH_LONG).show();
    }

    private void onSwipeDown(){
        Toast.makeText(this,"Swipe Down", Toast.LENGTH_LONG).show();
    }


    public static void start(Context context) {
        Intent starter = new Intent(context, WorkOfArt.class);
        context.startActivity(starter);
    }
}
