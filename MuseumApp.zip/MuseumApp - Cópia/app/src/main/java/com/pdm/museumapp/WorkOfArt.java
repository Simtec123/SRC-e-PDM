package com.pdm.museumapp;


import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;


import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.SuccessContinuation;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.pdm.museumapp.Data.ArtDatabase;
import com.pdm.museumapp.Data.ArtImages;
import com.pdm.museumapp.Data.Artifact;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import static android.view.GestureDetector.*;


public class WorkOfArt extends AppCompatActivity  {

    private static final String REFERENCIA = "Referencia";
    private static final String REFERENCIACAMINHO = "referenciaCaminho";
    private static final int SWIPE_TRESHHOLD = 100;
    private static final int SWIPE_VELOCITY_TRESHHOLD = 100;

    private int currentImgIndex = 0;
    private String audioName;
    private Uri audioUrl;
    private ArrayList<Integer> referenciasdeCaminhos;
    private List<Bitmap> imagens;
    private String videoUrl;
    private int referencia;
    private TextView discricao;
    private TextView nome;
    private TextView data;
    private TextView tipo;
    private ImageView photo;
    private ImageView Sound;
    private ImageView Video;
    private boolean flagForSound = false;
    private boolean flagForVideo = false;
    private GestureDetector gestureDetector;
    private View.OnTouchListener gestureListener;
    private MediaPlayer mp;
    private ScrollView sv;
    private boolean is_playing;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_work_of_art);

        imagens = new ArrayList<Bitmap>();
        //Setting the textView inside the parent scrollView scrollable
        discricao = findViewById(R.id.work_description);
        discricao.setMovementMethod(new ScrollingMovementMethod());
        sv = findViewById(R.id.scroll_id);
        is_playing = false;
        mp = new MediaPlayer();
        mp.setAudioStreamType(AudioManager.STREAM_MUSIC);

        discricao.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                discricao.getParent().requestDisallowInterceptTouchEvent(true);
                return false;
            }
        });
        sv.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                discricao.getParent().requestDisallowInterceptTouchEvent(false);
                return false;
            }
        });


        nome = findViewById(R.id.work_name);
        data = findViewById(R.id.work_century);
        tipo = findViewById(R.id.work_type);
        photo = findViewById(R.id.work_photos);
        Sound = findViewById(R.id.mic_button);
        Video = findViewById(R.id.play_video);




    }
    private void loadAudio(Context context){
        FirebaseStorage
                .getInstance()
                .getReference()
                .child(audioName + ".mp3")
                .getDownloadUrl()
                .addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        Log.e("AudioDebug", "Name of the audio: " + audioName+".mp3");
                        audioUrl = uri;
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Log.e("GetAudioDebug", "Umable to get the url " + e);
                Sound.setVisibility(View.GONE);
            }
        });


    }
    public void playSound(View view){
        if(!flagForSound) {
            if(!is_playing) {
                Sound.setImageResource(R.drawable.ic_pause);
                flagForSound = true;
                try {
                    mp.setDataSource(getBaseContext(), audioUrl);
                    mp.prepare();
                    mp.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                        @Override
                        public void onPrepared(MediaPlayer mp) {
                            Log.e("AudioDebug", "Sound Prepared");
                            mp.start();
                        }
                    });
                } catch (IOException e) {
                    Log.e("AudioDebug", "Unable to set data source " + e);
                }
                is_playing = true;
            }else{
                Sound.setImageResource(R.drawable.ic_pause);
                flagForSound = true;
                mp.start();
            }

        }else{
            Log.e("AudioDebug", "flagforsound" + flagForSound);
            Sound.setImageResource(R.drawable.mic);
            mp.pause();
            flagForSound = false;
        }
    }
    @Override
    protected void onStart() {
        super.onStart();

        int referencia = getIntent().getIntExtra(REFERENCIA,1);


        if(referencia == -1) {
            finish();
            return;
        }

        try{
            loadTask(referencia);
        }catch (Exception e){
            Log.e("WorkOfArt", "Ocorreu um erro com a seguinte exceção ao carregar os dados para a activity, Exception: " + e);
        }

        loadAudio(this);



        gestureDetector = new GestureDetector(new gestureListener());
        gestureListener = new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(gestureDetector.onTouchEvent(event)){
                    return true;
                }else{
                    return false;
                }

            }
        };
        photo.setOnTouchListener(gestureListener);

        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                Sound.setImageResource(R.drawable.mic);
                is_playing = false;
                flagForSound = false;
            }
        });


    }
    public static void start(Context context, int referencia) {
        Intent starter = new Intent(context, WorkOfArt.class);
        starter.putExtra(REFERENCIA, referencia);
        context.startActivity(starter);
    }
    public static void startWithArray(Context context, ArrayList<Integer> referencias) {
        Intent starter = new Intent(context, WorkOfArt.class);
        starter.putIntegerArrayListExtra(REFERENCIACAMINHO, referencias);
        context.startActivity(starter);
    }
    public void next(View view) {
        if(referencia < ArtDatabase.getInstance(this).artifactDao().getArtWorks().size()) {
            int referencia_temp = referencia + 1;
            Log.e("WorkOfArt1", "referencia atual " + referencia + "Referencia a seguir " + referencia_temp);
            start(this, referencia_temp);
        }
        else{
            Toast.makeText(this, "Não existem mais obras", Toast.LENGTH_LONG).show();
        }
    }
    public void previous(View view) {
        if(referencia > 1){
        int referencia_temp = referencia - 1;
        Log.e("WorkOfArt1", "referencia atual " + referencia + "Referencia a seguir " + referencia_temp);
        start(this, referencia_temp);
        }
        else{
            Toast.makeText(this, "Não é possivel ir para a obra anterior ", Toast.LENGTH_LONG).show();
        }
    }
    private void loadTask(int referencia){
      /*  try{
            //referenciasdeCaminhos.set(0 , referenciasdeCaminhos.get(0)+1);
        }catch (Exception e){
            Log.e("WorkOfArt", ""+e);
        }*/

        this.referencia = referencia;

        Artifact artifact = ArtDatabase.getInstance(getBaseContext()).artifactDao().getArt(referencia);
        Log.e("WorkOfArt", "som " + artifact.getSom());
        this.audioName = artifact.getSom();
        this.nome.setText(artifact.getNome());
        this.discricao.setText(artifact.getDescricao());
        this.data.setText(artifact.getData());
        this.tipo.setText(artifact.getGenero());
        this.videoUrl = artifact.getVideo();
        this.getImages(artifact);


    }
    private void getImages(Artifact artifact){
        for(ArtImages artImages : ArtDatabase.getInstance(this).imageDao().getArtImages(artifact.getReferencia())){
            byte[] photoByte = artImages.getImage();
            Bitmap bmp = BitmapFactory.decodeByteArray(photoByte, 0, photoByte.length);
            //Bitmap resized = Bitmap.createScaledBitmap(bmp,800, 800, true);
            imagens.add(bmp);
            Log.e("WorkOfArt", ""+imagens.size());
        }
        photo.setImageBitmap(imagens.get(0));
    }
    @Override
    protected void onResume() {
        super.onResume();
        if(flagForVideo){
            Video.setImageResource(R.drawable.ic_play_circle_outline_black_24dp);
            flagForVideo = false;
        }
    }
    public void playVideo(View view){

        if(!flagForVideo) {
            Video.setImageResource(R.drawable.ic_pause);
            flagForVideo = true;
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(videoUrl)));
        }else{
            Video.setImageResource(R.drawable.ic_play_circle_outline_black_24dp);
            flagForVideo = false;
        }
    }
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        super.dispatchTouchEvent(ev);
        return gestureDetector.onTouchEvent(ev);
    }
    class gestureListener extends SimpleOnGestureListener {

        @Override
        public boolean onFling(MotionEvent downEvent, MotionEvent moveEvent, float velocityX, float velocityY) {

            boolean result = false;
            float diffy = moveEvent.getY() - downEvent.getY();
            float diffx = moveEvent.getX() - downEvent.getX();
            Log.e("WorkOfArt", "tamanho do array de imagens " + imagens.size());

            if (Math.abs(diffx) > Math.abs(diffy)) {
                //Right or Left
                if (Math.abs(diffx) > SWIPE_TRESHHOLD && Math.abs(velocityX) > SWIPE_VELOCITY_TRESHHOLD) {
                    if (diffx > 0) {
                        //Swipe Right
                        onSwipeRight();
                    } else {
                        //Swipe Left
                        onSwipeLeft();
                    }
                    result = true;
                }
            } else {
                //Up or Down
                if (Math.abs(diffy) > SWIPE_TRESHHOLD && Math.abs(velocityY) > SWIPE_VELOCITY_TRESHHOLD) {
                    if (diffy > 0) {
                        //Swipe Down
                    } else {
                        //Swipe Up
                    }
                    result = true;
                }

            }
            return result;
        }
    }
    private void onSwipeLeft() {
        if(currentImgIndex > 0){currentImgIndex = currentImgIndex - 1;
            Log.e("WorkOfArt","index: " + currentImgIndex + "Tamanho da imagem no index dito" +imagens.get(currentImgIndex).getRowBytes() );
            //photo.setImageResource(R.drawable.example2);
            photo.setImageBitmap(imagens.get(currentImgIndex));

        }else{
            Log.e("WorkOfArt","Tentativa de exceder o array");
        }

    }
    private void onSwipeRight() {
        if(currentImgIndex < imagens.size()-1){
            currentImgIndex = currentImgIndex + 1;
            Log.e("WorkOfArt","index: " + currentImgIndex + "Tamanho da imagem no index dito" +imagens.get(currentImgIndex).getRowBytes() );
            //photo.setImageResource(R.drawable.example3);
            photo.setImageBitmap(imagens.get(currentImgIndex));
        }else{
            Log.e("WorkOfArt","Tentativa de exceder o array");}
    }
    public static void start(Context context) {
        Intent starter = new Intent(context, WorkOfArt.class);
        context.startActivity(starter);
    }
}
