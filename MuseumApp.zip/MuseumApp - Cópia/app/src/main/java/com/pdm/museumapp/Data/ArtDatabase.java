package com.pdm.museumapp.Data;

import android.arch.persistence.room.Database;
import android.arch.persistence.room.Room;
import android.arch.persistence.room.RoomDatabase;
import android.arch.persistence.room.TypeConverters;
import android.content.Context;

import com.pdm.museumapp.Data.Dao.ArtifactDao;
import com.pdm.museumapp.Data.Dao.ImageDao;

@Database(entities = {Artifact.class, ArtImages.class}, version = 1, exportSchema = false)
@TypeConverters({Converters.class})
public abstract class ArtDatabase extends RoomDatabase {

    private static ArtDatabase instance = null;

    public static ArtDatabase getInstance(Context context){
        context = context.getApplicationContext();
        if(instance == null){
            instance = Room.databaseBuilder(context, ArtDatabase.class, "Art_Db")
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build();
        }
        return instance;
    }


    public abstract ArtifactDao artifactDao();
    public abstract ImageDao imageDao();
}
