package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import java.util.Map;

@Entity(tableName = "Obras")
public class Artifact {

    @PrimaryKey(autoGenerate = true)
    private int Referencia;

    private String Data;
    private String Descricao;
    private Map<String, String> Fotos;
    private String Genero;
    private String Nome;
    private String Video;
    private String Tipo;
    private String som;


    @Ignore
    public Artifact() {

    }

    public Artifact(int Referencia, String Data, String Descricao, Map<String, String> Fotos, String Genero, String Nome, String Video, String Tipo, String som) {
        this.Referencia = Referencia;
        this.Data = Data;
        this.Descricao = Descricao;
        this.Fotos = Fotos;
        this.Genero = Genero;
        this.Nome = Nome;
        this.Video = Video;
        this.Tipo = Tipo;
        this.som = som;
    }

    public String getSom() {
        return som;
    }

    public void setsom(String som) {
        this.som = som;
    }

    public int getReferencia() {
        return Referencia;
    }

    public void setReferencia(int referencia) {
        Referencia = referencia;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public Map<String, String> getFotos() {
        return Fotos;
    }

    public void setFotos(Map<String, String> fotos) {
        Fotos = fotos;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String genero) {
        Genero = genero;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getVideo() {
        return Video;
    }

    public void setVideo(String video) {
        Video = video;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        this.Tipo = tipo;
    }
}
