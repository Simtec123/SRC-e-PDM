package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.PrimaryKey;

@Entity(tableName = "Caminhos")
public class Paths {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String tipo_caminho;
    private String obras;
    private String mapas_obras;

}
