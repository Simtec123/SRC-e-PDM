package com.pdm.museumapp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.storage.FirebaseStorage;
import com.pdm.museumapp.Data.ArtDatabase;
import com.pdm.museumapp.Data.ArtImages;
import com.pdm.museumapp.Data.Artifact;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class museumApp extends Application {

    @Override
    public void onCreate() {
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Obras");
        super.onCreate();

        FirebaseFirestore instance = FirebaseFirestore.getInstance();
        FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(false)
                .build();
        instance.setFirestoreSettings(settings);

        final SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        boolean firstTime = prefs.getBoolean("firstTime", true);
        Log.e("WorkOfArt", "Starting the app " + "Prefs are: "+ firstTime);

       if(firstTime) {
            Log.e("WorkOfArt", "Reference: " + dbRef);
            dbRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.e("WorkOfArt", "onDataChange");
                    prefs.edit().putBoolean("firstTime", false).apply();
                    List<Artifact> Art = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Artifact artifact = snapshot.getValue(Artifact.class);
                        Log.e("WorkOfArt", "Add work: " + artifact.getNome());
                        Art.add(artifact);
                        addImages(artifact);

                        ArtDatabase.getInstance(getApplicationContext()).artifactDao().insertArt(artifact);
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("WorkOfArt", "Erro: "+ databaseError);
                }
            });
       }
        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Artifact artifact = dataSnapshot.getValue(Artifact.class);
                ArtDatabase
                        .getInstance(getApplicationContext())
                        .artifactDao()
                        .insertArt(artifact);
                addImages(artifact);
                Log.e("Firebase", "Child was added " + artifact.getReferencia() );
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                Artifact artifact = dataSnapshot.getValue(Artifact.class);
                ArtDatabase
                        .getInstance(getApplicationContext())
                        .artifactDao()
                        .update(artifact);
                addImages(artifact);

                Log.e("Firebase", "Child was changed " + artifact.getReferencia() );
            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                Artifact artifact = dataSnapshot.getValue(Artifact.class);
                ArtDatabase
                        .getInstance(getApplicationContext())
                        .artifactDao()
                        .delete(artifact);

                Log.e("Firebase", "Child was removed " + artifact.getReferencia() );
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("Firebase", "Listener was cancelled" + databaseError);
            }
        });
    }

    private void addImages(final Artifact artifact){
        for(int i = 1; i <= artifact.getFotos().size(); i++ ) {
            Log.e("WorkOfArt", "Adding image: " + i + "/"+artifact.getFotos().size());
            FirebaseStorage
                    .getInstance()
                    .getReference()
                    .child("obras/"+artifact.getFotos().get("fotografia"+i)  + ".jpg")
                    .getBytes(1024 * 1024)
                    .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Log.e("WorkOfArt", "obras/"+artifact.getFotos().get("fotografia"+1)  + ".jpg");
                                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            byte[] photoBytes = getBytesFromBitmap(bmp);
                            int artReference = artifact.getReferencia();
                            ArtImages artImages = new ArtImages(0, artReference, photoBytes);
                            Toast.makeText(getBaseContext(),"" + ArtDatabase.getInstance(getBaseContext()).imageDao().insertArt(artImages),Toast.LENGTH_LONG).show();
                            Log.e("WorkOfArt", "Photo Added!" );
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e("museumApp", "Unable to get image " + e);
                }
            });


        }
    }


    private byte[] getBytesFromBitmap(Bitmap bmp) {
        if(bmp == null) return null; // If there the bitmap is null

        // Initialization of a ByteArrayOutputStream Object so that it we can write the bitmap to it and later turn it to a byteArray
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        // Compressing the Bitmap into the ByteArrayOutputStream that we defined before
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        //Retrieving the byteArray from the bitmap
        byte[] byteArray = stream.toByteArray();
        // Returning the byteArray
        return byteArray;
    }
}
