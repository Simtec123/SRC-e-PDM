#from appJar import gui
#app = gui()
#app.go()



file = open("testfile.txt", "r")
rows = file.readline()
columns = file.readline(1)

print("rows: " + rows,"cols: " + columns)

key = "cadeiro"
matrix = []
for e in key.upper():
    if e not in matrix:
        matrix.append(e)

alphabet = "ABCDEFGHIKLMNOPQRSTUVWXYZ"



for e in alphabet:
    if e not in matrix:
        matrix.append(e)



# initialize a new list.
rows = []
for e in range(5):
    rows.append('')

for x in range(5):
    rows[x] = matrix[5 * x:5 * (x + 1)]

#for row in rows:
 #   print (' '.join(row))


