package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

import static android.arch.persistence.room.ForeignKey.CASCADE;

@Entity(tableName = "Caminhos",foreignKeys = {
        @ForeignKey(
                onDelete = CASCADE,
                entity = linksInPaths.class,
                parentColumns = "id",
                childColumns = "id_linksInPath"
        ),

})
public class Paths {

    @PrimaryKey(autoGenerate = true)
    private int id;

    private String tipo;
    private String id_linksInPath;

    public Paths(int id, String tipo, String id_linksInPath) {
        this.id = id;
        this.tipo = tipo;
        this.id_linksInPath = id_linksInPath;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getId_linksInPath() {
        return id_linksInPath;
    }

    public void setId_linksInPath(String id_linksInPath) {
        this.id_linksInPath = id_linksInPath;
    }
}
