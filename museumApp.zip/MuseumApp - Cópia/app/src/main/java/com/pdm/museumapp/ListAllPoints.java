package com.pdm.museumapp;

import android.arch.lifecycle.Observer;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapShader;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.BitmapDrawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.pdm.museumapp.Data.ArtDatabase;
import com.pdm.museumapp.Data.ArtImages;
import com.pdm.museumapp.Data.Artifact;
import com.pdm.museumapp.Utils.BlurBluider;
import com.pdm.museumapp.Utils.ObservableInteger;
import com.pdm.museumapp.Utils.OnIntegerChangeListener;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

public class ListAllPoints extends AppCompatActivity {

    private RecyclerView listOfPoi;
    private WorkAdapter workAdapter;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_all_points);

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null) {
            getSupportActionBar().setDisplayShowHomeEnabled(true); // ligar essa funcionalidade
            getSupportActionBar().setIcon(R.drawable.mus_icon); // colocar o icon
        }

        this.listOfPoi = findViewById(R.id.item_list);
        this.listOfPoi.setLayoutManager(new LinearLayoutManager(this));
        this.workAdapter = new WorkAdapter();
        this.listOfPoi.setAdapter(workAdapter);

        ArtDatabase.getInstance(getApplicationContext())
                .imageDao()
                .getAllImages()
                .observe(this, new Observer<List<ArtImages>>() {
                    @Override
                    public void onChanged(@Nullable List<ArtImages> artImages) {
                        updateData();
                    }
                });

        ObservableInteger observableInteger = new ObservableInteger();

        observableInteger.setOnIntegerChangeListener(new OnIntegerChangeListener() {
            @Override
            public void onIntegerChanged(int newValue) {
                Toast.makeText(getBaseContext(), "Value of count " + newValue, Toast.LENGTH_LONG).show();
            }
        });

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.list_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.refresh_list:
                update();
                return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void update(){
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Obras");
        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Log.e("WorkOfArt", "onDataChange");
                List<Artifact> Art = new ArrayList<>();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Artifact artifact = snapshot.getValue(Artifact.class);
                    Log.e("WorkOfArt", "Add work: " + artifact.getNome());
                    artifact.setReferencia(snapshot.getKey());
                    Art.add(artifact);
                    if(artifact.getFotos() != null){
                        //  Log.e("WebApiTest","getfotos is not null");
                        addImages(artifact);
                    }
                    Log.e("WorkOfArt", "insertArt: " + ArtDatabase.getInstance(getApplicationContext()).artifactDao().insertArt(artifact));
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.e("WorkOfArt", "Erro: "+ databaseError);
            }
        });
    }

    private void addImages(final Artifact artifact){
        for(int i = 1; i <= artifact.getFotos().size(); i++ ) {
            Log.e("WorkOfArt", "Adding image: " + i + "/"+artifact.getFotos().size());
            FirebaseStorage
                    .getInstance()
                    .getReference()
                    .child("Obras/"+artifact.getReferencia()+"/images/"+artifact.getFotos().get("fotografia"+i))
                    .getBytes(1024 * 1024)
                    .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Log.e("WorkOfArt", "obras/"+artifact.getFotos().get("fotografia"+1)  + ".jpg");
                            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            byte[] photoBytes = getBytesFromBitmap(bmp);
                            String artReference = artifact.getReferencia();
                            ArtImages artImages = new ArtImages(0, artReference, photoBytes);
                            ArtDatabase.getInstance(getBaseContext()).imageDao().insertArt(artImages);
                            Log.e("WorkOfArt", "Photo Added!" );
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e("museumApp", "Unable to get image " + e);
                }
            });
        }
        Log.e ("Testing", "Size of Local db on museum app on addedimages" + ArtDatabase.getInstance(this).artifactDao().getArtWorks().size());
    }
    private byte[] getBytesFromBitmap(Bitmap bmp) {
        if(bmp == null) return null; // If there the bitmap is null

        // Initialization of a ByteArrayOutputStream Object so that it we can write the bitmap to it and later turn it to a byteArray
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        // Compressing the Bitmap into the ByteArrayOutputStream that we defined before
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        //Retrieving the byteArray from the bitmap
        byte[] byteArray = stream.toByteArray();
        // Returning the byteArray
        return byteArray;
    }

    private void updateData(){
        List<Artifact> artifacts = ArtDatabase.getInstance(getApplicationContext()).artifactDao().getArtWorks();
        workAdapter.setData(artifacts);
    }

    public static void start(Context context) {
        Intent starter = new Intent(context, ListAllPoints.class);
        context.startActivity(starter);

    }

    private class WorkViewHolder extends RecyclerView.ViewHolder{

        private Artifact artifact;

        ImageView work_image;
        TextView woe_Title;
        TextView work_gender;
        TextView work_data;


        WorkViewHolder(@NonNull View itemView) {
            super(itemView);
            work_image = itemView.findViewById(R.id.image_item);
            work_gender = itemView.findViewById(R.id.item_gender);
            work_data = itemView.findViewById(R.id.item_date);
            woe_Title = itemView.findViewById(R.id.title_item);
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    WorkOfArt.start(ListAllPoints.this, artifact.getReferencia());
                }
            });
        }

        void bind(Artifact artifact){
            this.artifact = artifact;
            this.woe_Title.setText(artifact.getNome());
            this.work_gender.setText(artifact.getGenero());
            this.work_data.setText(artifact.getData());
            this.work_image.setImageBitmap(getartImage(artifact));

           }

        Bitmap getartImage(Artifact artifact) {
            Bitmap image = null;
            try {

                ArtImages artImages = ArtDatabase.getInstance(getApplicationContext()).imageDao().getArtImages(artifact.getReferencia()).get(0);
                byte[] photoByte = artImages.getImage();
                image = BitmapFactory.decodeByteArray(photoByte, 0, photoByte.length);
               // image = Bitmap.createScaledBitmap(image, 1200, 800, true);
                image = BlurBluider.blur(getBaseContext(), image);
                Bitmap imageRounded = Bitmap.createBitmap(image.getWidth(), image.getHeight(), image.getConfig());
                Canvas canvas = new Canvas(imageRounded);
                Paint mpaint = new Paint();
                mpaint.setAntiAlias(true);
                mpaint.setShader(new BitmapShader(image, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP));
                canvas.drawRoundRect((new RectF(0, 0, image.getWidth(), image.getHeight())), 100, 100, mpaint);// Round Image Corner 100 100 100 100


                return imageRounded;
            }catch (Exception e){
                Log.e("ItemList", "This item problably has no images " + artifact.getReferencia());
            }

            return null;
        }
    }

    private class WorkAdapter extends RecyclerView.Adapter<WorkViewHolder>{

        private List<Artifact> data;

        public void setData(List<Artifact> artifacts){
            this.data = artifacts;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public WorkViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_list, viewGroup, false);
            return new WorkViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull WorkViewHolder workViewHolder, int i) {
            Artifact artifact = data.get(i);
            workViewHolder.bind(artifact);
        }

        @Override
        public int getItemCount() {
            return data == null ? 0 : data.size();
        }
    }


}
