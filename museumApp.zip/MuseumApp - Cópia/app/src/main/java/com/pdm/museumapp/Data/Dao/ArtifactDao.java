package com.pdm.museumapp.Data.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.pdm.museumapp.Data.Artifact;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;
@Dao
public interface ArtifactDao {
    @Insert(onConflict = REPLACE)
    long insertArt(Artifact artifact);

    @Update(onConflict = REPLACE)
    void update(Artifact artifact);

    @Delete
    void delete(Artifact artifact);

    @Query("SELECT * from Obras")
    List<Artifact> getArtWorks();

    @Query("select * from Obras")
    LiveData<List<Artifact>> getAllArtifacts();

    @Query("SELECT Referencia from Obras WHERE fbKey = :key")
    int validate(String key);

    @Query("SELECT Referencia from Obras WHERE fbKey = :key")
    String getObjectBykey(String key);

    @Query("SELECT * from Obras WHERE Referencia = :referencia")
    Artifact getArt(String referencia);
}
