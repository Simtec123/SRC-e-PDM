package com.pdm.museumapp.Data.Dao;

import android.arch.lifecycle.LiveData;
import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import com.pdm.museumapp.Data.ArtImages;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
public interface ImageDao {
    @Insert(onConflict = REPLACE)
    long insertArt(ArtImages artImages);

    @Update(onConflict = REPLACE)
    int update(ArtImages artImages);

    @Delete
    int delete( ArtImages artImages);

    @Query("SELECT * from Imagens")
    List<ArtImages> getArtWorks();

    @Query("SELECT * from Imagens WHERE ArtReference = :referencia")
    List<ArtImages> getArtImages(String referencia);

    @Query("SELECT * from Imagens")
    LiveData<List<ArtImages>> getAllImages();

}
