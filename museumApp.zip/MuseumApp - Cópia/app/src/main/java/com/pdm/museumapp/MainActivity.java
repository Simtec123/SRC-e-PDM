package com.pdm.museumapp;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.ml.vision.FirebaseVision;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcode;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetector;
import com.google.firebase.ml.vision.barcode.FirebaseVisionBarcodeDetectorOptions;
import com.google.firebase.ml.vision.common.FirebaseVisionImage;
import com.pdm.museumapp.Data.ArtDatabase;
import com.pdm.museumapp.Data.Artifact;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import dmax.dialog.SpotsDialog;

public class MainActivity extends AppCompatActivity {


    AlertDialog waitingDialog;
    ImageView search;

    private static final int PHOTO_REQUEST_CODE = 123;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
       search = findViewById(R.id.pesquisar);

        waitingDialog = new  SpotsDialog.Builder()
                .setContext(this)
                .setMessage("Please wait")
                .build();

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                takePhoto(v);
            }
        });
    }
    public void takePhoto(View view) {

        Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);

        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(intent, PHOTO_REQUEST_CODE);
        }

    }
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if(requestCode == PHOTO_REQUEST_CODE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            // Getting picture Thumbnail
            Bitmap bitmap = (Bitmap) extras.get("data");
            runDetector(bitmap);
        }
    }
    private void runDetector(Bitmap bitmap) {
        waitingDialog.show();
        Log.e("BarCodeRead", "Detecting...");
        FirebaseVisionImage image = FirebaseVisionImage.fromBitmap(bitmap);
        FirebaseVisionBarcodeDetectorOptions options = new FirebaseVisionBarcodeDetectorOptions.Builder()
                .setBarcodeFormats(
                        FirebaseVisionBarcode.FORMAT_QR_CODE
                ).build();
        FirebaseVisionBarcodeDetector detector = FirebaseVision.getInstance().getVisionBarcodeDetector(options);
        detector.detectInImage(image)
                .addOnSuccessListener(new OnSuccessListener<List<FirebaseVisionBarcode>>() {
                    @Override
                    public void onSuccess(List<FirebaseVisionBarcode> firebaseVisionBarcodes) {
                        Log.e("BarCodeRead", "It has detected something");
                        Log.e("BarCodeRead", "firebaseVisionBarcodes size: " + firebaseVisionBarcodes.size());
                        processResult(firebaseVisionBarcodes);
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(MainActivity.this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });

    }
    private void processResult(List<FirebaseVisionBarcode> firebaseVisionBarcodes) {
        Log.e("BarCodeRead", "" + firebaseVisionBarcodes.size());
        Log.e("BarCodeRead", "Processing...");
        for (final FirebaseVisionBarcode item : firebaseVisionBarcodes){
            int value_type = item.getValueType();

            Log.e("BarCodeRead", "It has detected a DisplayValue " + item.getDisplayValue());
            Log.e("BarCodeRead", "It has detected a valueType: " + value_type);
            Log.e("BarCodeRead", "It has detected a valueType: " + item.getRawValue());
            switch (value_type)
            {
                case FirebaseVisionBarcode.TYPE_TEXT:
                {
                    android.support.v7.app.AlertDialog.Builder builder = new android.support.v7.app.AlertDialog.Builder(this);
                    builder.setMessage(item.getRawValue());
                    builder.setPositiveButton("Ver Obra", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            WorkOfArt.start(MainActivity.this, item.getRawValue());
                        }
                    });
                    android.support.v7.app.AlertDialog dialog = builder.create();
                    dialog.show();
                }
                break;

                default:
                {
                    Toast.makeText(MainActivity.this, "Detetado tipo incorreto de Codigo QR", Toast.LENGTH_LONG).show();
                }
            }


        }
    }
    public void goTo(View view){
       List<Artifact> artifacts = ArtDatabase.getInstance(this).artifactDao().getArtWorks();
        //WorkOfArt.start(this, artifacts.get(0).getReferencia());
        ListAllPoints.start(this);
    }


}
