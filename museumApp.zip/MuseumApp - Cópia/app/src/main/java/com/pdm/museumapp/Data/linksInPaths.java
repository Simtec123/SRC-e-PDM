package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.PrimaryKey;

import static android.arch.persistence.room.ForeignKey.CASCADE;

@Entity(tableName = "links",foreignKeys = {
        @ForeignKey(
                onDelete = CASCADE,
                entity = Ligacao.class,
                parentColumns = "id",
                childColumns = "id_ligacao"
        ),
        @ForeignKey(
                onDelete = CASCADE,
                entity = Paths.class,
                parentColumns = "id",
                childColumns = "id_Path"
        ),

})
public class linksInPaths {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int id_Path;
    private int ordem;
    private int id_ligacao;

    public linksInPaths(int id, int id_Path, int ordem, int id_ligacao) {
        this.id = id;
        this.id_Path = id_Path;
        this.ordem = ordem;
        this.id_ligacao = id_ligacao;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getId_Path() {
        return id_Path;
    }

    public void setId_Path(int id_Path) {
        this.id_Path = id_Path;
    }

    public int getOrdem() {
        return ordem;
    }

    public void setOrdem(int ordem) {
        this.ordem = ordem;
    }

    public int getId_ligacao() {
        return id_ligacao;
    }

    public void setId_ligacao(int id_ligacao) {
        this.id_ligacao = id_ligacao;
    }
}

