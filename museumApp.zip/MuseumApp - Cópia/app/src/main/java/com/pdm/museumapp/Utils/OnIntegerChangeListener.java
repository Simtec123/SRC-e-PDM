package com.pdm.museumapp.Utils;

public interface OnIntegerChangeListener {
    public void onIntegerChanged(int newValue);
}

