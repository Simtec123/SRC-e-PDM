package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.ForeignKey;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

import static android.arch.persistence.room.ForeignKey.CASCADE;

@Entity(tableName = "Imagens",foreignKeys = {
        @ForeignKey(
                onDelete = CASCADE,
                entity = Artifact.class,
                parentColumns = "Referencia",
                childColumns = "ArtReference"
        )},
        indices = {
        @Index(name = "index_referencia", value = "ArtReference")
        }
)
public class ArtImages {

    @PrimaryKey(autoGenerate = true)
    private long id;

    private String ArtReference;

    private byte[] image;



    public ArtImages(long id, String ArtReference, byte[] image) {
        this.id = id;
        this.ArtReference = ArtReference;
        this.image = image;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getArtReference() {
        return ArtReference;
    }

    public void setArtReference(String artReference) {
        ArtReference = artReference;
    }

    public byte[] getImage() {
        return image;
    }

    public void setImage(byte[] image) {
        this.image = image;
    }
}
