package com.pdm.museumapp.Data;

import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Ignore;
import android.arch.persistence.room.PrimaryKey;
import android.support.annotation.NonNull;

import java.util.Map;

@Entity(tableName = "Obras")
public class Artifact {

    @NonNull
    @PrimaryKey()
    private String Referencia;

    private String Data;
    private String Descricao;
    private String fbKey;
    private Map<String, String> Fotos;
    private String Genero;
    private String Nome;
    private String Video;
    private String Tipo;
    private String Som;


    @Ignore
    public Artifact() {

    }

    public Artifact(String Data, String Descricao, Map<String, String> Fotos, String Genero, String Nome, String Video, String Tipo, String Som) {
        this.Referencia = "";
        this.Data = Data;
        this.Descricao = Descricao;
        this.Fotos = Fotos;
        this.Genero = Genero;
        this.Nome = Nome;
        this.Video = Video;
        this.Tipo = Tipo;
        this.Som = Som;
    }

    public String getFbKey() {
        return fbKey;
    }

    public void setFbKey(String fbKey) {
        this.fbKey = fbKey;
    }

    @NonNull
    public String getReferencia() {
        return Referencia;
    }

    public void setReferencia(@NonNull String referencia) {
        this.Referencia = referencia;
    }

    public String getSom() {
        return Som;
    }

    public void setsom(String som) {
        this.Som = som;
    }

    public String getData() {
        return Data;
    }

    public void setData(String data) {
        Data = data;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    public Map<String, String> getFotos() {
        return Fotos;
    }

    public void setFotos(Map<String, String> fotos) {
        Fotos = fotos;
    }

    public String getGenero() {
        return Genero;
    }

    public void setGenero(String genero) {
        Genero = genero;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getVideo() {
        return Video;
    }

    public void setVideo(String video) {
        Video = video;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        this.Tipo = tipo;
    }
}
