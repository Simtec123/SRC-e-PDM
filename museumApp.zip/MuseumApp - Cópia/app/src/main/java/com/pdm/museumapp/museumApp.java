package com.pdm.museumapp;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreSettings;
import com.google.firebase.storage.FirebaseStorage;
import com.pdm.museumapp.Data.ArtDatabase;
import com.pdm.museumapp.Data.ArtImages;
import com.pdm.museumapp.Data.Artifact;
import com.pdm.museumapp.Utils.ObservableInteger;
import com.pdm.museumapp.Utils.OnIntegerChangeListener;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Handler;
import java.util.logging.LogRecord;

public class museumApp extends Application {

    private int counter = 0;
    private ObservableInteger observableInteger = new ObservableInteger();
    @Override
    public void onCreate() {
        DatabaseReference dbRef = FirebaseDatabase.getInstance().getReference("Obras");

        super.onCreate();


        FirebaseFirestore instance = FirebaseFirestore.getInstance();
        final FirebaseFirestoreSettings settings = new FirebaseFirestoreSettings.Builder()
                .setPersistenceEnabled(false)
                .build();
        instance.setFirestoreSettings(settings);

        final SharedPreferences prefs = getSharedPreferences("app_prefs", Context.MODE_PRIVATE);
        boolean firstTime = prefs.getBoolean("firstTime", true);
        int addItems = prefs.getInt("added", 0);
        boolean firstTime_temp = true;
        Log.e("WorkOfArt", "Starting the app " + "Prefs are: "+ firstTime);

       if(firstTime && firstTime_temp) {

            firstTime_temp = false;
            dbRef.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                    Log.e("WorkOfArt", "onDataChange");
                    prefs.edit().putBoolean("firstTime", false).apply();
                    List<Artifact> Art = new ArrayList<>();
                    for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                        Artifact artifact = snapshot.getValue(Artifact.class);
                        Log.e("WorkOfArt", "Add work: " + artifact.getNome());
                        artifact.setReferencia(snapshot.getKey());
                        Art.add(artifact);
                        if(artifact.getFotos() != null){
                          //  Log.e("WebApiTest","getfotos is not null");
                            addImages(artifact);
                        }


                      Log.e("WorkOfArt", "insertArt: " + ArtDatabase.getInstance(getApplicationContext()).artifactDao().insertArt(artifact));
                    }
                }
                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("WorkOfArt", "Erro: "+ databaseError);
                }
            });
       }else{
        dbRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                counter = observableInteger.get();
                counter++;
                observableInteger.set(counter);
               /* try{
                    Artifact artifact = dataSnapshot.getValue(Artifact.class);
                    artifact.setReferencia(dataSnapshot.getKey());
                    ArtDatabase
                            .getInstance(getApplicationContext())
                            .artifactDao()
                            .insertArt(artifact);
                    if (artifact.getFotos() != null) {
                        Log.e("WebApiTest", "getfotos is not null");
                        addImages(artifact);
                    }
                    Log.e("FirebaseCustomaction", "Child was added " + artifact.getReferencia());

                }catch (Exception e){
                    Log.e("Loading Data", "There was a delay while loading the data " + e);

                }*/
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                try {
                        Artifact artifact = dataSnapshot.getValue(Artifact.class);
                        String key = dataSnapshot.getKey();
                        List<Artifact> artifacts = ArtDatabase.getInstance(getApplicationContext()).artifactDao().getArtWorks();
                        String ref = ArtDatabase.getInstance(getApplicationContext()).artifactDao().getObjectBykey(key);
                        if (ref != null) {
                            artifact.setReferencia(ref);
                            ArtDatabase
                                    .getInstance(getApplicationContext())
                                    .artifactDao()
                                    .update(artifact);
                            if (artifact.getFotos() != null) {
                                updateImages(artifact);
                            }
                            Log.e("FirebaseCustomaction", "Child was changed " + artifact.getNome());

                        } else {
                            Log.e("FirebaseCustomaction", "Cant change Child " + artifact.getNome());
                        }
                }catch (Exception e){
                    Log.e("Loading Data", "There was a delay while loading the data " + e);
                }

            }

            @Override
            public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                Artifact artifact = dataSnapshot.getValue(Artifact.class);
                artifact.setReferencia(dataSnapshot.getKey());
                ArtDatabase
                        .getInstance(getApplicationContext())
                        .artifactDao()
                        .delete(artifact);

                Log.e("FirebaseCustomaction", "Child was removed " + artifact.getReferencia() );
            }

            @Override
            public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) { }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                    Log.e("FirebaseCustomaction", "Listener was cancelled" + databaseError);
            }
        });
       }


        Log.e ("Testing", "Size of Local db on museum app on create" + ArtDatabase.getInstance(this).artifactDao().getArtWorks().size());
    }

    private void addImages(final Artifact artifact){
        for(int i = 1; i <= artifact.getFotos().size(); i++ ) {
            Log.e("WorkOfArt", "Adding image: " + i + "/"+artifact.getFotos().size());
            FirebaseStorage
                    .getInstance()
                    .getReference()
                    .child("Obras/"+artifact.getReferencia()+"/images/"+artifact.getFotos().get("fotografia"+i))
                    .getBytes(1024 * 1024)
                    .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Log.e("WorkOfArt", "obras/"+artifact.getFotos().get("fotografia"+1)  + ".jpg");
                                    Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            byte[] photoBytes = getBytesFromBitmap(bmp);
                            String artReference = artifact.getReferencia();
                            ArtImages artImages = new ArtImages(0, artReference, photoBytes);
                            ArtDatabase.getInstance(getBaseContext()).imageDao().insertArt(artImages);
                            Log.e("WorkOfArt", "Photo Added!" );
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e("museumApp", "Unable to get image " + e);
                }
            });


        }

        Log.e ("Testing", "Size of Local db on museum app on addedimages" + ArtDatabase.getInstance(this).artifactDao().getArtWorks().size());
    }

    private void updateImages(final Artifact artifact){
        for(int i = 1; i <= artifact.getFotos().size(); i++ ) {
            Log.e("WorkOfArt", "Adding image: " + i + "/"+artifact.getFotos().size());
            FirebaseStorage
                    .getInstance()
                    .getReference()
                    .child("Obras/"+artifact.getReferencia()+"/images/"+artifact.getFotos().get("fotografia"+i))
                    .getBytes(1024 * 1024)
                    .addOnSuccessListener(new OnSuccessListener<byte[]>() {
                        @Override
                        public void onSuccess(byte[] bytes) {
                            Log.e("WorkOfArt", "obras/"+artifact.getFotos().get("fotografia"+1)  + ".jpg");
                            Bitmap bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
                            byte[] photoBytes = getBytesFromBitmap(bmp);
                            String artReference = artifact.getReferencia();
                            ArtImages artImages = new ArtImages(0, artReference, photoBytes);
                            ArtDatabase.getInstance(getBaseContext()).imageDao().update(artImages);
                            Log.e("WorkOfArt", "Photos Update!" );
                        }
                    }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.e("museumApp", "Unable to get image " + e);
                }
            });


        }
    }




    private byte[] getBytesFromBitmap(Bitmap bmp) {
        if(bmp == null) return null; // If there the bitmap is null

        // Initialization of a ByteArrayOutputStream Object so that it we can write the bitmap to it and later turn it to a byteArray
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        // Compressing the Bitmap into the ByteArrayOutputStream that we defined before
        bmp.compress(Bitmap.CompressFormat.JPEG, 70, stream);
        //Retrieving the byteArray from the bitmap
        byte[] byteArray = stream.toByteArray();
        // Returning the byteArray
        return byteArray;
    }
}
