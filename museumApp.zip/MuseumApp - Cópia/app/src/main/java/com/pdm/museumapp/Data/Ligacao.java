package com.pdm.museumapp.Data;

import android.arch.persistence.room.PrimaryKey;

public class Ligacao {

    @PrimaryKey(autoGenerate = true)
    private int id;
    private int referencia_obra_inicio;
    private int referencia_obra_fim;
    private byte[] mapa;

    public Ligacao(int id, int referencia_obra_inicio, int referencia_obra_fim, byte[] mapa) {
        this.id = id;
        this.referencia_obra_inicio = referencia_obra_inicio;
        this.referencia_obra_fim = referencia_obra_fim;
        this.mapa = mapa;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getReferencia_obra_inicio() {
        return referencia_obra_inicio;
    }

    public void setReferencia_obra_inicio(int referencia_obra_inicio) {
        this.referencia_obra_inicio = referencia_obra_inicio;
    }

    public int getReferencia_obra_fim() {
        return referencia_obra_fim;
    }

    public void setReferencia_obra_fim(int referencia_obra_fim) {
        this.referencia_obra_fim = referencia_obra_fim;
    }

    public byte[] getMapa() {
        return mapa;
    }

    public void setMapa(byte[] mapa) {
        this.mapa = mapa;
    }

}
